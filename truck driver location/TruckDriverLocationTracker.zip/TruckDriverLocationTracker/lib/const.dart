String androidMapKey = 'AIzaSyAT7JkP1Gm_jxtBewJr40mcGcRCAuSI97Q';
String iOSMapKey = 'AIzaSyDwBxFrqz_J7ZOO1j8nz72eHAxd9oHwV2Y';
String mainKey = 'AIzaSyCib-td2dHvs3ZsBzUQgd5F8cLMiqdw9pE';
